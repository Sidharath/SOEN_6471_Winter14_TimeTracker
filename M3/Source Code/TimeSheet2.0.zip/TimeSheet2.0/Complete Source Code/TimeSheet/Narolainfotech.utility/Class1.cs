﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Narolainfotech.utility
{
    public class Class1
    {
    }
}
