using System;
using System.Collections.Generic;
using System.Text;

namespace NarolaInfotech.Utility
{
    public static class  clsMessage
    {
        public enum RETURN_STATUS
        {
            OK = 0,
            NOT_OK = -100
        }
    }
   
}
