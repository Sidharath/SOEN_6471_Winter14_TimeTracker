using System;
using System.Collections.Generic;
using System.Text;

namespace NarolaInfotech.Utility
{
  public static class clsConst
  {
    public const string DATETIME_NULL = "01/01/1900";
  }
}
