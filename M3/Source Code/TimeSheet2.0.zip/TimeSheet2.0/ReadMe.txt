After you configure timesheet application, you may access the same using below URL and login details. 

*You should rename "TimeSheet2.0" in below URLs with application name you have choosen during installation/configuration.

User Panel
----------
http://localhost/TimeSheet2.0/Login.aspx
Id : emp1@www.narolainfotech.com
Password : password


Admin
-----
http://localhost/TimeSheet2.0/admin/AdminLogin.aspx
Id : admin
Password : admin