﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class ReportViewer_testasd : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		 string strConnection = System.Configuration.ConfigurationManager.ConnectionStrings["DataAccessQuickStart"].ConnectionString.ToString();

        SqlConnection MyConnection = new SqlConnection(strConnection);
        MyConnection.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = MyConnection;

        //cmd.CommandText = "select * from TimeSheetDetail TSD inner join TimeSheet TS on TSD.nmTimeSheetID = TS.nmTimeSheetID where TSD.nmProjectID=88";
        //cmd.CommandText = "update TimeSheetDetail set nmHourID = '01:01' where nmTimeSheetDetail=877";
		cmd.CommandText = "SELECT SUM(CONVERT(decimal(10,2),REPLACE(TSD.nmHourID,':','.'))) AS Hours,UM.szContactPerson FROM  TimeSheet TS INNER JOIN TimeSheetDetail TSD ON TS.nmTimeSheetID = TSD.nmTimeSheetID AND TSD.nmProjectID = 88 AND TS.dtCreateDate BETWEEN '2012-11-15' AND '2012-12-15' INNER JOIN dbo.UserMaster UM ON UM.nmUserID = TS.nmUserID AND UM.szArchive = '0' GROUP BY  UM.szContactPerson";
		cmd.CommandType = CommandType.Text;
        SqlDataAdapter adp = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        adp.Fill(ds);
		DataTable outputTable = ds.Tables[0].Clone();

        for (int i = ds.Tables[0].Rows.Count - 1; i >= 0; i--)
        {
            outputTable.ImportRow(ds.Tables[0].Rows[i]);
        }

        GridView1.DataSource = outputTable;
        GridView1.DataBind();
    }
	
	protected void btnGetQuery_Click(object sender, EventArgs e)
        {
		string strConnection = System.Configuration.ConfigurationManager.ConnectionStrings["DataAccessQuickStart"].ConnectionString.ToString();

			SqlConnection MyConnection = new SqlConnection(strConnection);
			MyConnection.Open();
			SqlCommand cmd = new SqlCommand();
			cmd.Connection = MyConnection;
		
            string Query = string.Empty;
            Query = txtGetQuerry.Text;

			cmd.CommandText = Query; 
			cmd.CommandType = CommandType.Text;
			SqlDataAdapter adp = new SqlDataAdapter(cmd);
			DataSet ds = new DataSet();
			adp.Fill(ds);
			DataTable outputTable = ds.Tables[0].Clone();

			for (int i = ds.Tables[0].Rows.Count - 1; i >= 0; i--)
			{
				outputTable.ImportRow(ds.Tables[0].Rows[i]);
			}

			 GridView1.DataSource = outputTable;
        GridView1.DataBind();
			}
		
}